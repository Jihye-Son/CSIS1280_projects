function changeColor(){

    var color = document.getElementsByName('color');
    var fontcolor = {"red":"red", "blue":"blue", "green":"green"};

    for(var i = 0; i<color.length; i++)
    {
        color[i].onclick = function(){
            document.getElementById("text").style.color = fontcolor[this.value];
        }
    }   

}


function changeBg(){
    
    var bg = document.getElementsByName('color2');
    var bgcolor = {"nothing":"white","red":"red", "blue":"blue", "green":"green"};
   
    for(var i =0; i<bg.length; i++)
    {
        bg[i].onchange = function(){
            document.getElementById("td_text").style.backgroundColor = bgcolor[this.value];
        }
    }   


}
