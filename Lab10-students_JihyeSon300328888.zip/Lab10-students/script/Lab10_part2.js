var topPosition = 100;
var leftPosition = -100;



function runPuppy() {
    var puppy = document.getElementById("puppy");
    

    puppy.style.position = "absolute";
    puppy.style.left = leftPosition + "px";
    puppy.style.top = topPosition + "px";
    puppy.style.visibility = "visible";
    
    leftPosition += 6;
    topPosition += 1;
    puppy.style.left =  leftPosition + "px";
    puppy.style.top =  topPosition + "px";
    
  
    if(leftPosition >= screen.availWidth -100){
        topPosition = 100;
        leftPosition = -100;
    }
   
}
    


    
    
// add if it reaches the screen end (you can check with screen.availwidth)					

