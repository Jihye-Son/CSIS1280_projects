/*Add the JavaScript here for the function billingFunction().  It is responsible for setting and clearing the fields in Billing Information */

function copyFunction(){
    if(document.getElementById('same').checked){
         var nameTake = document.getElementById('shippName').value;
         var codeTake = document.getElementById('shippZip').value;
         document.getElementById('billing').value = nameTake;
         document.getElementById('Zip').value = codeTake;       
    }else{
         document.getElementById('billing').value = "";
         document.getElementById('Zip').value = "";
    }
  }