function copy(){
    var operand1 = document.getElementById("text").value;
    document.getElementById("copyplace").value = operand1;
}